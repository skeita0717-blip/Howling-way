/****************************************************************
 * Howling way サイト用  スプレッドシート → JSON API
 * ------------------------------------------------------------
 * このコードを Google スプレッドシートの
 * 「拡張機能 > Apps Script」に貼り付けて公開すると、
 * シートの内容をサイトが読み取れる JSON に変換します。
 ****************************************************************/

function doGet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();

  var result = {
    news:   readSheet(ss, 'News'),
    shows:  readSheet(ss, 'Shows'),
    movies: readSheet(ss, 'Movies'),
    disco:  readSheet(ss, 'Disco')
  };

  return ContentService
    .createTextOutput(JSON.stringify(result))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * 指定したシートを読み取り、1行目を見出し（キー）として
 * オブジェクトの配列に変換する。
 * 「公開」列が FALSE の行はスキップする。
 */
function readSheet(ss, sheetName) {
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet) return [];

  var values = sheet.getDataRange().getValues();
  if (values.length < 2) return [];

  var headers = values[0];
  var rows = [];

  for (var i = 1; i < values.length; i++) {
    var row = values[i];
    var obj = {};
    var hasContent = false;

    for (var c = 0; c < headers.length; c++) {
      var key = String(headers[c]).trim();
      if (!key) continue;
      var val = row[c];

      // 日付型はそのまま文字に
      if (val instanceof Date) {
        val = Utilities.formatDate(val, 'Asia/Tokyo', 'yyyy.MM.dd');
      }
      obj[key] = (val === '' || val === null) ? '' : String(val);
      if (obj[key]) hasContent = true;
    }

    // 「公開」列が FALSE / 非公開 / no の行は出さない
    var pub = String(obj['公開'] || obj['publish'] || '').toLowerCase();
    if (pub === 'false' || pub === 'no' || pub === '非公開' || pub === '0') continue;

    // 空行はスキップ
    if (!hasContent) continue;

    // News の本文を <p> でラップ（改行を段落に）
    if (sheetName === 'News' && obj.body) {
      obj.body = obj.body
        .split(/\n+/)
        .filter(function(t){ return t.trim(); })
        .map(function(t){ return '<p>' + t.trim() + '</p>'; })
        .join('');
    }

    delete obj['公開'];
    delete obj['publish'];
    rows.push(obj);
  }

  return rows;
}
